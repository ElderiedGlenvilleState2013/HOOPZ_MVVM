//
//  User.swift
//  HoopZ
//
//  Created by dadDev on 12/1/20.
//

import Foundation
struct User {
    var firstName: String
    var lastName: String
    var email: String
  //  var id: UUID?
    var sport: String
    var canPlayBall: Bool
    var imageUrl: String
    var homeGym: String
   // var location: UserLocation?
    
}
