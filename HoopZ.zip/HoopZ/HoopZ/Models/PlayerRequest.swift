//
//  PlayerRequest.swift
//  HoopZ
//
//  Created by dadDev on 12/15/20.
//

import Foundation

struct PlayerRequest {
    var sender: String
    var receiver: String
}
