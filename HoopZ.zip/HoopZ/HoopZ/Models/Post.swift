//
//  Post.swift
//  HoopZ
//
//  Created by dadDev on 12/1/20.
//

import Foundation
struct Post {
    var user: User
    var available: String
    var gymName: String
}
