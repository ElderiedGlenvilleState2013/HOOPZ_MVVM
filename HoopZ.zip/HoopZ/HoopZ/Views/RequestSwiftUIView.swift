//
//  RequestSwiftUIView.swift
//  HoopZ
//
//  Created by dadDev on 12/11/20.
//

import SwiftUI

struct RequestSwiftUIView: View {
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
    }
}

struct RequestSwiftUIView_Previews: PreviewProvider {
    static var previews: some View {
        RequestSwiftUIView()
    }
}
